import { useEffect } from "react";
import gsap from "gsap";
import { motion } from "framer-motion";
import Lenis from "@studio-freight/lenis";

export default function App(){

  useEffect(()=>{
    const lenis = new Lenis({ smooth: true });
    function raf(time){
      lenis.raf(time);
      requestAnimationFrame(raf);
    }
    requestAnimationFrame(raf);

    gsap.from(".hero-title", { y:100, opacity:0, duration:1 });
  },[]);

  return(
    <div className="container">

      <section className="hero">
        <motion.h1 
          className="hero-title"
          initial={{opacity:0,y:50}}
          animate={{opacity:1,y:0}}
          transition={{duration:1}}
        >
          GymPro
        </motion.h1>

        <motion.p 
          initial={{opacity:0}}
          animate={{opacity:1}}
          transition={{delay:0.5}}
        >
          Elite Training Experience
        </motion.p>
      </section>

      <section className="cards">
        {[1,2,3].map(i=>(
          <motion.div 
            key={i}
            className="card"
            whileHover={{scale:1.05}}
          >
            Feature {i}
          </motion.div>
        ))}
      </section>

    </div>
  );
}
